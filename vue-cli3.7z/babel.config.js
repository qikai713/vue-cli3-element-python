module.exports = {
  presets: [
    '@vue/app', { plugins: ["transform-vue-jsx"],}
  ],

}
