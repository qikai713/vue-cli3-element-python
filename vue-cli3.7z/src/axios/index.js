import Vue from 'vue';
import axios from 'axios';

/*使用axios插件*/
Vue.prototype.$axios = axios;
export default({
});